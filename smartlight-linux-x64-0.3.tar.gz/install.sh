# installs the binaries to /usr/local/bin/

cp smservice /usr/local/bin/
cp smtray /usr/local/bin/
cp smcli /usr/local/bin/